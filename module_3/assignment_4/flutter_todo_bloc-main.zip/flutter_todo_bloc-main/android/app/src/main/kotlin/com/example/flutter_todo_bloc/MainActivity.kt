package com.example.flutter_todo_bloc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
